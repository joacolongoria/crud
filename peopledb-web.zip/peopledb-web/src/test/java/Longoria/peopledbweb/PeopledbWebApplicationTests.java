package Longoria.peopledbweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeopledbWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
