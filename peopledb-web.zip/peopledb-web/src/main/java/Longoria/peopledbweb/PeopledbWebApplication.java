package Longoria.peopledbweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopledbWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeopledbWebApplication.class, args);
	}

}
